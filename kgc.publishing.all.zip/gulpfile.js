const
	gulp 			= require('gulp'),
	htmlInclude = require('gulp-file-include'),
	webpack = require('webpack'),
	webpackConfig = require('./webpack.config.js'),
	cssbeauty	= require('gulp-cssbeautify');

gulp
.task('beautify', _ => {
	return gulp.src('./build/front/css/kgc.all.css')
		.pipe(cssbeauty({autosemicolon: true}))
		.pipe(gulp.dest('./build/front/css/'));
})

.task( 'htmlParsing', () => {
	return gulp.src(['./**/html/**/*.html', './**/html/**/**/*.html'], {base : './src/html/'})
		.pipe(htmlInclude({	
			prefix: '@@',
			basepath: '@file'
		}))
		.pipe(gulp.dest('./build/html/'));
})

// 항상 주시하기
.task( 'watch', ['beautify', 'htmlParsing'], () => {
	gulp.watch( './build/front/css/kgc.all.css', ['beautify'] );
	gulp.watch(['./src/html/**/*.html', './src/html/**/**/*.html'], ['htmlParsing']);
})

//기본 동작 설정
.task( 'default', ['watch'] );