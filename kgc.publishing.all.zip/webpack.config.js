const webpack = require("webpack")
	,ExtractTextPlugin = require("extract-text-webpack-plugin")
	,beautify = require("js-beautify-loader")
	,LiveReload = require('webpack-livereload-plugin')
	,path = require('path')
	,LiveReloadPlugin = require('webpack-livereload-plugin');

module.exports = {
	watrch: true
	,context: __dirname
	,entry: {
		"polyfill": './src/front/js/polyfill.js',
		"ui.kgc": './src/front/js/ui.common.js'
		// "jquery": './src/js/concat-core.js',
		// ,"swiper.umd.min": './src/js/swiper.jquery.umd.min.js'
		//style 불러오기
		// "kgc.common": "./src/front/scss/kgc.common.scss",
		// "kgc.layout": "./src/front/scss/kgc.layout.scss",
		// "kgc.main": "./src/front/scss/kgc.main.scss",
		// "kgc.sub": "./src/front/scss/kgc.sub.scss",
		// "kgc.swiper": "./src/front/scss/kgc.swiper.scss"
	}
	,output: {
		path: path.resolve(__dirname, 'build/front/js')
		,publicPath: path.resolve(__dirname, '/')
		,filename: '[name].js'
	}
	,module: {
		loaders: [
			{
				test: /\.scss$/,
				loader: ExtractTextPlugin.extract('style', 'css!autoprefixer-loader?browsers=android 2.3!sass', {
					allChunks: true
				})
			}
			,{
				test: /\.js$/,
				exclude: /node_module/,
				loader: 'babel',
				query: {
					presets: ['es2015', 'stage-3']
				}
			}
			,{
				test: /\.json$/,
				loader: 'json'
			}
		]
	}
	,resolve: {
		extensions: ['', '.js', '.scss']
	}
	,plugins: [
		new ExtractTextPlugin('../css/kgc.all.css'),
		new LiveReloadPlugin()
		// ,new webpack.HotModuleReplacementPlugin()
	]
	,devServer: {
		host: 'localhost',
		port: 1234,
		contentBase: './build'
		// historyApiFallback: true,
		// hot: true,
		// inline: true,
		// progress: true
	}
	,devtool: '#inline-source-map'
	,debug: true
}
