// import './dev'; //개발용 스크립트 프로덕션시 삭제
import '../scss/concat.scss';
/*import '../scss/kgc.common.scss';
import '../scss/kgc.layout.scss';
import '../scss/kgc.sub.scss';
import '../scss/kgc.main.scss';
import '../scss/kgc.swiper.scss';*/

var $ = window.$;
var win = window,
	doc = document;

win.ui = window.ui || {

	//공통
	common: {
		// 빈 함수 클릭시 오류 방지
		commonNothing: function() {},

		// a태그의 href 값이 # 일경우 commonNothing()으로 대체
		emptyLinkFunc: function() {
			//a태그 href에 더미 함수 삽입
			var allA = doc.querySelectorAll('a'),
				aTag = null,
				href = null;
			for (var i = 0, length = allA.length; i < length; i++) {
				aTag = allA[i];
				href = aTag.getAttribute('href');
				if (ui.util.trim(href) == '#' || href == null)
					aTag.setAttribute('href', 'javascript:ui.common.commonNothing();');
			}
		},

		toggleNavi: {
			flag: true,
			open: function () {
				var navi = $('#navi'),
				 	body = $('body');
				body.append('<div class="dimm"></div>');
				navi.addClass('active');
				if ( this.flag ) {
					this.flag = false;
					navi.find('.navi-list > li > a').on('click', function(){
						$(this).parent().addClass('active').siblings('li').removeClass('active');
					});
					this.depth3Toggle();
				}
			},
			close: function () {
				$('#navi').removeClass('active');
				$('body > .dimm').remove();
			},
			depth3Toggle: function(){
				$('.navi-list-sub > li.hasList > a').on('click', function(){
					var list = $(this).next('.navi-list-sub-02'),
						parent = $(this).parent(),
						speed = 200;
					if ( parent.hasClass('active') ) {
						list.stop().slideUp(speed, function(){
							parent.removeClass('active');
						})
					} else {
						parent.addClass('active');
						list.stop().slideDown(speed, function(){
						});
						parent.siblings().find('.navi-list-sub-02').stop().slideUp(speed, function(){
							$(this).parent().removeClass('active');
						});
					}
				});
			}
		},

		toggleCategory: function() {
			var scope = $('.category-list'),
				d1 = scope.find('.depth1'),
				d2 = scope.find('depth2');

			d1.find('>li>a').on('click', function(){
				var $this = $(this),
					parent = $this.parent(),
					speed = 300;
				$this.next('.depth2').slideDown(speed, function(){
					parent.addClass('active');
				});

				parent.siblings().find('.depth2').slideUp(speed, function(){
					$(this).parent().removeClass('active');
				});
			});
		},

		//검색 레이어
		searchLayer: function() {
			var header = $('#header'),
			 	body = $('body');
			header.find('.btn-search').on('click', function(){
				body.find(' > .search').addClass('active');
				body.append('<div class="dimm"></div>');

				$('.dimm').add( body.find('> .search button.btn-close') ).on('click', function(){
					body.find(' > .search').removeClass('active');
					$('.dimm').remove();
				});
			});
		},

		subnaviPositionSet: function(){
			var executer = function(){
				var scope = $('.sub-navi'),
					el = scope.find('li'),
					ul = scope.find('> ul').get(0),
					elLength = el.length,
					activeEl = scope.find('.active').get(0),
					allWidth = 0,
					currentLeft = 0,
					i = 0;
				for ( ; i < elLength; i+=1 ) {
					allWidth += el.eq(i).width();
				}

				if ( allWidth > scope.outerWidth() ) {
					scope.addClass('end-fade');
					currentLeft = activeEl.offsetLeft - (window.innerWidth / 2) + ( activeEl.clientWidth / 2 )
					ul.scrollLeft = currentLeft;

					$(ul).on('scroll', function(){
						var that = $(this).get(0),
							left = that.scrollLeft;
						if ( left < 1 ) {
							$(this).parent().removeClass('start-fade');
						} else if ( left >= 1 ) {
							$(this).parent().addClass('start-fade');
						}

						if ( left >= (that.scrollWidth - $(this).parent().width()) ) {
							$(this).parent().removeClass('end-fade')
						} else if ( left < (that.scrollWidth - $(this).parent().width()) ) {
							$(this).parent().addClass('end-fade')
						}
					}).trigger('scroll');
				}
			};
			executer();
		}

	},

	util: {

		// 양쪽 여백 제거
		trim: function(str) {
			if (str == null || typeof str == 'undefined') return "";
			return str.replace(/^\s+|\s+$/g, "");
		},

		//글자수 자르기
		cutstr: function cutStr(str, limit){    
			var strLength = 0,
				strTitle = "",
				strPiece = "",
				code, ch;
			
			for (i = 0; i < str.length; i++){
				code = str.charCodeAt(i),
				ch = str.substr(i,1).toUpperCase();
				strPiece = str.substr(i,1)
				code = parseInt(code);
				
				if ((ch < "0" || ch > "9") && (ch < "A" || ch > "Z") && ((code > 255) || (code < 0)))
					strLength = strLength + 3; //UTF-8 3byte 로 계산
				else
					strLength = strLength + 1;
				
				if(strLength>limit) //제한 길이 확인
					break;
				else strTitle = strTitle+strPiece; //제한길이 보다 작으면 자른 문자를 붙여준다.
			}
			return strTitle;
		},

		// mobile detecting
		isDevice: function() {
			//모바일 UA
			var ua = navigator.userAgent;
			return {
				check: function() {
					if (this.android) {
						if (this.gingerbread) return 'gingerbread';
						else return 'android';
					}
					if (this.ios) return 'ios';
					if (!this.android && !this.ios) return 'no-mobile';
				},
				ios: ua.match('iPhone') ? true : false,
				android: ua.match('Android') ? true : false,
				gingerbread: ua.match('Android 2.3') ? true : false
			}
		},
		deviceSize: 'device-size-' + window.innerWidth

	},


	//슬라이드 참고 사이트 : http://idangero.us/swiper/api/#.WFsqHraLSAw
	swiper: {
		_scope: '',

		defaultOptions: {
			direction: 'horizontal',
			loop: true,
			pagination: '.swiper-pagination',
			paginationType: 'fraction'
		},

		init: function(scope, options) {
			this._scope = scope;
			var assign = (typeof Object.assign == 'undefined') ? $.extend : Object.assign; //assign 함수 존재 여부 체크, 없으면 $.extend로 대체
			options = (typeof options == 'undefined') ? this.defaultOptions : assign({}, this.defaultOptions, options); //options 매개변수가 undefined 일 경우를 체크하여 오류 방지
			this.swiper(options);
		},

		swiper: function(options) {
			$(this._scope).data('manager', new Swiper(this._scope, options));
		},

		manager: function() {
			return $(this._scope).data('manager');
		}
	}

};



//DOM 로드후 화면 보여줌
win.addEventListener('DOMContentLoaded', function(){
	$( document.body ).stop().animate({ opacity: 1 }, 300, function(){
	});
});

$(function() {

	var util = ui.util,
		common = ui.common,
		isDevice = util.isDevice();


	//빈 링크 채우기
	common.emptyLinkFunc();

	//검색창 열기
	common.searchLayer();

	//모바일 넓이, OS 클래스 삽입
	$('body').addClass([isDevice.check(), util.deviceSize].join(' '));

	//navigation open
	$('a.btn-navi').on('click', function(){
		common.toggleNavi.open();
		$('body > .dimm').on('click', function() {
			common.toggleNavi.close();
		})
	});

	//sub navi
	if ( $('body').has('.sub-navi') ) {
		ui.common.subnaviPositionSet();
	}

	//navigation close
	$('#navi .btn-close').on('click', function(){
		common.toggleNavi.close();
	});

	//위로가기
	$('button.to-top').on('click', function(){
		$('body, html').stop().animate({scrollTop: 0}, 300, 'easeInOutQuart', function(){});
	});


	// kgc.accordian.init('.accordian');

});
