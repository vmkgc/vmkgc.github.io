const [win, doc, qsa, qs] = [window, document, 'querySelectorAll', 'querySelector'];

const
	dom 	= s => document[qs](s),
	domAll 	= s => document[qsa](s),
	makeDom = (s, attr) => {
		var dom = document.createElement(s)
		if ( typeof attr == 'object' && Object.keys(attr).length > 0 )
			for ( let i in attr )
				dom.setAttribute(i, attr[i]);
		return dom;
	},
	putText = s => document.createTextNode(s),
	prepend = (item, target) => target.insertBefore(item, target.childNodes[0]),
	append 	= (item, target) => target.appendChild(item);

const menuData = [
	{
		depth1: "공통",
		depth2: "",
		links: [
			{
				title: "댓글",
				href: "/html/common/reply.html",
				complete: true
			},
			{
				title: "내용이 없을 때",
				href: "/html/common/no-reply.html",
				complete: true
			},
			{
				title: "confirm, alert",
				href: "/html/config/locationServiceAgreement.html",
				complete: true
			}

		]
	},
	{
		depth1: "브랜드메인",
		depth2: "매장정보",
		links: [
			{
				title: "매장소식",
				href: "/html/brand/storeInfo/storeNews.html",
				complete: true
			},
			{
				title: "백화점행사(Sample)",
				href: "/html/brand/storeEvent.html",
				complete: true
			}
		]
	},
	{
		depth1: "",
		depth2: "매장방문후기",
		links: [
			{
				title: "상세",
				href: "/html/brand/visitorsBookDetail.html",
				complete: false
			}
		]
	},
	{
		depth1: "멤버쉽",
		depth2: "이용약관",
		links: [
			{
				title: "서비스 이용약관 (뷰티포인트 웹)",
				href: "/html/membership/serviceAgreement/service.html",
				complete: true
			},
			{
				title: "개인정보 처리방침 (뷰티포인트 웹)",
				href: "/html/membership/serviceAgreement/personalInfomation.html",
				complete: true
			},
			{
				title: "위치기반서비스 이용약관",
				href: "/html/membership/serviceAgreement/locationBased.html",
				complete: true
			}
		]
	},
	{
		depth1: "이벤트&행사",
		depth2: "진행중인 이벤트",
		links: [
			{
				title: "상세 - 일반",
				href: "/html/event/ongoing/view.html",
				complete: true
			},
			{
				title: "상세 - 헤라메이크업쇼",
				href: "/html/event/ongoing/viewHera.html",
				complete: true
			},
			{
				title: "상세 (투표하기 - 단일선택)",
				href: "/html/event/ongoing/viewPoll_singleSelect.html",
				complete: true
			},
			{
				title: "상세 (투표하기 - 복수선택)",
				href: "/html/event/ongoing/viewPoll_multiSelect.html",
				complete: true
			},
			{
				title: "상세 (투표완료)",
				href: "/html/event/ongoing/viewPollComplete.html",
				complete: true
			},
			{
				title: "상세 (투표종료 후 확인)",
				href: "/html/event/ongoing/viewPoll_finish.html",
				complete: true
			},
			{
				title: "예약 시 - 개인정보 수집 및 이용안내",
				href: "/html/event/reservation/agreement.html",
				complete: true
			}
		]
	},
	{
		depth1: "쿠폰북",
		depth2: "",
		links: [
			{
				title: "상세",
				href: "/html/couponBook/detail.html",
				complete: true
			}
		]
	},
	{
		depth1: "뷰티컨텐츠",
		depth2: "목록",
		links: [
			{
				title: "상세(카드뉴스형)",
				href: "/html/beautyContent/cardType.html",
				complete: true,
			},
			{
				title: "상세(동영상형)",
				href: "/html/beautyContent/movieType.html",
				complete: true,
			}
		]
	},
	{
		depth1: "상품정보",
		depth2: "",
		links: [
			{
				title: "상품 상세",
				href: "/html/productInfo/view.html",
				complete: true
			}
		]
	},
	{
		depth1: "상품 상세",
		depth2: "",
		links: [
			{
				title: "상품리뷰",
				href: "/html/productReview/view.html",
				complete: true
			}
		]
	},
	{
		depth1: "고객센터",
		depth2: "공지사항",
		links: [
			{
				title: "목록 + 상세",
				href: "/html/cs/notice/list.html",
				complete: true
			}
		]
	},
	{
		depth1: "도움말",
		depth2: "",
		links: [
			{
				title: "메인",
				href: "/html/cs/help/index.html",
				complete: true
			}
		]
	},
	{
		depth1:"마이페이지" ,
		depth2: "",
		links: [
			{
				title: "나의 등급",
				href: "/html/myPage/grade/index.html",
				complete: true	
			},
			{
				title: "브랜드별 매장선택",
				href: "/html/myPage/selectStore/index.html",
				complete: true	
			},
			{
				title: "나의 쿠폰",
				href: "/html/myPage/coupon/index.html",
				complete: true	
			},
			{
				title: "나의 리뷰 - 방문후기",
				href: "/html/myPage/myReview/visitorsBook.html",
				complete: true
			},
			{
				title: "나의 리뷰 - 상품리뷰",
				href: "/html/myPage/myReview/index.html",
				complete: true
			},
			{
				title: "관심상품",
				href: "/html/myPage/productOfInterest/index.html",
				complete: true
			}
		]
	},
	{
		depth1: "",
		depth2: "구매현황",
		links: [
			{
				title: "리스트(popup 포함)",
				href: "/html/myPage/purchase/period.html",
				complete: true
			}
		]
	},
	{
		depth1: "엔젤톡톡",
		depth2: "",
		links: [
			{
				title: "대화화면",
				href: "/html/engelTalk/talk_inquiry.html",
				complete: true	
			}
		]
	}

];

var menuList = menuData.reduce((p, c) => {
	let {depth1, depth2, links} = c;
	return `${p || ''}
	${depth1 ? `<h2><span>${depth1}</span></h2>` : ``}
	${depth2 == '' ? depth2 : `<h3><span>${depth2}</span></h3>`}
	<ul>${links.reduce((ip, ic) => {
			let {title, href, complete} = ic;
			return `${ip || ""}
		<li${complete ? ' class="cp"' : ""}><a href="${href}">${title}</a></li>`}, 0)}
	</ul>
	`
}, 0);

// 메뉴 버튼 삽입
window.dev = {
	appendMenuBtn: function(){
		var menuTrigger = `<button type="button" class="menu-trigger">
	<span>toggle menu</span>
</button>`;
	
			if ( $('button.menu-trigger').length <= 0) {
				$('#menu').prepend(menuTrigger);
			}
	
			$('.menu-trigger').on('click', function () {
				var menuList = $('#menu-list'),
				    ctrlClass = 'is-active',
				    condition = menuList.hasClass( ctrlClass );
				if (condition) {
					menuList.add($(this)).removeClass( ctrlClass );
				} else {
					menuList.add($(this)).addClass( ctrlClass );
				}
			});
	}

	// 메뉴 리스트 삽입
	,appendMenuList: function(){

		if ( $('#menu').length <= 0 ) {
			menuList = $('<div id=menu />').append( $('<div id=menu-list class=overthrow />').append( menuList ) );
			$('#wrap').length <= 0 ? $('body').prepend( menuList ) : $('#wrap').prepend( menuList );
		}
		$('#menu-list').find('a').each(function(){
			var aHREF = $(this).attr('href');
			if ( aHREF.indexOf('?dev') <= -1 ) {
				$(this).attr('href', aHREF + '?dev');
			}
		});
	}
	,dimm: function(msg){
		msg = msg || '내용이 없습니다.';
		$('body').append(
			$('<div class="dimm" />').append(
				$(`<span>${msg}<span/><button class="close">[닫기]</span></button>`)
			)
		);
		$('.dimm').on('click', '.close', function(){
			$('.dimm').remove();
		});
	}
};

